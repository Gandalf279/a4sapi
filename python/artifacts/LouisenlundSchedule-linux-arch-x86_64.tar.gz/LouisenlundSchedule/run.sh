#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ ! -d "_internal" || ! -f "_internal/libpython3.14.so.1.0" ]]; then
  echo "LouisenlundSchedule is incomplete: the _internal runtime folder is missing." >&2
  echo "Extract the complete .tar.gz package; do not copy the executable on its own." >&2
  exit 1
fi
exec "./LouisenlundSchedule" "$@"
